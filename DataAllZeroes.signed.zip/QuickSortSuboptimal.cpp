#include "QuickSortSuboptimal.h"

QuickSortSuboptimal::QuickSortSuboptimal() : QuickSorter("Quicksort suboptimal") {}
QuickSortSuboptimal::~QuickSortSuboptimal()
{}
/***** Complete this file. *****/

