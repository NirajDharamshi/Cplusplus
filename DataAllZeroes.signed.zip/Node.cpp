#include "Node.h"
#include "Element.h"

/***** Complete this file. *****/
Node::Node(Element elmt):element(elmt)
{
   next=nullptr;
}